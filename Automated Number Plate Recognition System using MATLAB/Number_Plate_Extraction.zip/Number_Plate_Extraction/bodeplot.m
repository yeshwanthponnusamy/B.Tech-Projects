clear all
num=[1 1];
den=[1 12 20 0];
sys=tf(num,den)
num1=
controlSystemDesigner(sys)
