clc
clear all
num=[3.51];
den=[0.1 0.7 1 0];
sys=tf( num, den) % for finding transfer function of the system
bode(sys) % draws the Bode plot of the dynamic system sys
bode(sys,{0, 1000})% draws the Bode plot for frequencies between wmin and wmax in
%radians/s
bode(sys,10)
[MAG,PHASE] = bode(sys, 10)
bodemag(sys) % plots the magnitude of the frequency response of the linear system sys
bodeplot (sys) % draws the Bode plot of the dynamic system sys. The frequency range
%and number of points are chosen automatically
[Gm,Pm,Wcg,Wcp] = margin(sys)
controlSystemDesigner(sys)