clc
num=30;
denom=[1 11 30];
sys= tf(num,denom)
%rlocus(sys)
stepinfo(sys)
controlSystemDesigner(sys)